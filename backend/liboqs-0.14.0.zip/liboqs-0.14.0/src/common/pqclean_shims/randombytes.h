// SPDX-License-Identifier: MIT

#ifndef RANDOMBYTES_H
#define RANDOMBYTES_H

#include <oqs/rand.h>

#define randombytes OQS_randombytes

#endif
